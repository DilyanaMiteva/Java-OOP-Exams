package bakery.repositories;

import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.drinks.interfaces.Drink;
import bakery.repositories.interfaces.DrinkRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DrinkRepositoryImpl implements DrinkRepository<Drink> {

    private List<Drink> models;

    public DrinkRepositoryImpl(){
        this.models = new ArrayList<>();
    }

    @Override
    public Drink getByNameAndBrand(String drinkName, String drinkBrand) {
        return null;
    }

    @Override
    public Collection<Drink> getAll() {
        return null;
    }

    @Override
    public void add(Drink drink) {

    }
}
